# Kawamonn - オンラインストレージサービス プロジェクト説明書

## 📋 プロジェクト概要

**Kawamonn** は、Raspberry Pi 5で稼働するオンラインストレージサービスです。会津大学の学生が資料やファイルをクラウドに保存・共有できるサービスとして設計されています。

### 主な特徴
- **20GBのストレージクォータ** を各ユーザーに提供
- **@u-aizu.ac.jp アカウントの自動有効期限管理** （卒業/退職時のデータ削除）
- **リアルタイムなクォータ監視** とファイル管理
- **セキュアな認証** （パスワードハッシュ化、JWT、2要素認証対応）
- **監査ログ** ですべての重要な操作を記録
- **ファイル共有機能** （トークンベース、パスワード保護対応）

---

## 🏗️ アーキテクチャ全体図

```
┌─────────────────────────────────────────────────────────┐
│                      ユーザーブラウザ                        │
└────────────┬─────────────────────────────────────────────┘
             │
    ┌────────▼────────────────────────────────────────┐
    │ kawamonn-storage-frontend (React / Vite)        │
    │ Modern SPA UI                                   │
    └────────┬────────────────────────────────────────┘
             │
    ┌────────▼────────────────────────────────────────┐
    │ kawamonn-storage-backend (NestJS)               │
    │ REST API (port 3000)                            │
    │ ├─ 認証 (JWT, 2FA)                             │
    │ ├─ ファイル管理                                   │
    │ ├─ ユーザー管理                                   │
    │ ├─ 監査ログ                                      │
    │ └─ SSH コンテナ管理                               │
    └────────┬────────────────────────────────────────┘
             │
    ┌────────┴──────────────────────────┬─────────┐
    │                                   │         │
┌───▼──────┐  ┌────────┐  ┌─────────┐  │  ┌──────▼──┐
│PostgreSQL│  │ MinIO  │  │ Redis   │  │  │Mailgun  │
│(Metadata)│  │(Files) │  │(Cache)  │  │  │(Email)  │
└──────────┘  └────────┘  └─────────┘  │  └─────────┘
                                        │
                              ┌─────────▼────────┐
                              │ Cloudflare       │
                              │ - セキュリティ    │
                              │ - DNS            │
                              │ - Access Policy  │
                              └──────────────────┘

    ┌───────────────────────────────────┐
    │   ファイルシステム (/home/pi/hdd/)  │
    │   ├─ users/                       │
    │   │  ├─ user1/                    │
    │   │  ├─ user2/                    │
    │   │  └─ ...                       │
    │   └─ ssh/                         │
    │      └─ kawamonn-storage/         │
    └───────────────────────────────────┘
```

---

## 🔍 主要コンポーネント詳細

### 1️⃣ **kawamonn-storage-backend** (NestJS モダンアーキテクチャ)

`TypeScript/NestJS` で実装された本格的なエンタープライズ向けAPI。

#### **技術スタック**

- **フレームワーク**: NestJS (Node.js/Express ベース)
- **言語**: TypeScript
- **DB**: PostgreSQL + Prisma ORM
- **ファイルストレージ**: MinIO (S3互換)
- **キャッシュ/ブローカー**: Redis
- **ジョブキュー**: BullMQ
- **認証**: JWT + Passport
- **セキュリティ**: bcrypt/argon2 パスワードハッシュ

#### **Prisma データベーススキーマ**

```
User
├── id (UUID)
├── account_name (UNIQUE)
├── email (UNIQUE)
├── password_hash (bcrypt or argon2)
├── two_factor_secret (QR code用)
├── role: "user" | "admin"
├── quota_bytes, used_bytes
├── created_at, updated_at
└── relations: files[], shares[], audit_logs[]

File (ファイル/フォルダ)
├── id (UUID)
├── owner_id → User
├── parent_id → File (親フォルダ、NULL = ルート)
├── name
├── size (bytes)
├── mime_type ("image/jpeg", "application/pdf", "directory" etc)
├── storage_key ("user_id/file_id-original_filename")
├── version (バージョン番号)
└── relations: children[], versions[], shares[]

FileVersion
├── id (UUID)
├── file_id → File
├── storage_key (MinIO)
├── version_number
└── created_at

Share (共有リンク)
├── id (UUID)
├── file_id → File
├── token (UNIQUE - URLの共有トークン)
├── expires_at (有効期限)
├── password_hash (パスワード保護)
├── max_downloads (最大ダウンロード数)
├── created_by → User
└── created_at

AuditLog
├── id (UUID)
├── actor_id → User (誰が)
├── action ("UPLOAD", "DELETE", "SHARE", "LOGIN")
├── target_type ("file", "user", "share")
├── target_id (対象のID)
├── metadata (JSON - 追加情報)
└── created_at

SshContainer
├── id (UUID)
├── username
├── container_id (Docker)
├── image_tag
├── cpu_limit, memory_limit
├── created_at, last_started_at
```

#### **モジュール構成**

```
src/
├── main.ts                 # アプリケーション起動
├── app.module.ts           # ルートモジュール
├── app.controller.ts       # ルートエンドポイント
└── modules/
    ├── auth/              # 認証ロジック
    │  ├── auth.service.ts    (JWT、OTP、2FA)
    │  ├── auth.controller.ts (login, register, sendOtp)
    │  └── jwt.strategy.ts    (Passport JWT戦略)
    │
    ├── users/             # ユーザー管理
    │  ├── users.service.ts
    │  └── users.controller.ts
    │
    ├── files/             # ファイル操作
    │  ├── files.service.ts   (MinIO連携)
    │  ├── files.controller.ts
    │  └── files.processor.ts (BullMQ ジョブ)
    │
    ├── admin/             # 管理者機能
    │  └── admin.service.ts
    │
    └── ssh/               # SSHコンテナ管理
       └── ssh.service.ts
```

#### **認証フロー**

```typescript
// ユーザー登録フロー
1. client.register(email, password, display_name)
   ↓
2. auth.service.sendOtp(email)
   - @u-aizu.ac.jp のみ許可
   - 6桁OTPコード生成
   - Nodemailer で OTP メール送信
   ↓
3. client.register(registerDto + otp_code)
   ↓
4. auth.service.register()
   - OTP コード検証
   - account_name 生成 (display_name or email prefix)
   - ユーザー作成
   - JWT トークン発行
   ↓
5. /api/v1/auth/login
   - account_name + password
   - JWT トークン + refresh_token 返却
```

**パスワードハッシュ:**
- 新規: bcrypt (12rounds)
- レガシー対応: argon2 も検証可

**2要素認証 (Optional):**
- TOTP (Time-based One-Time Password)
- QR code で設定
- `two_factor_secret` に秘密鍵保存

#### **ファイル管理フロー**

```typescript
// ファイルアップロード
1. POST /api/v1/files/upload
   - Form-Data で file + parentId
   - JWT 認証必須
   ↓
2. files.service.uploadFile()
   - ユーザークォータチェック (used_bytes + file.size <= quota_bytes)
   - MinIO に storage_key で保存
   - DB に File レコード作成
   - AuditLog に記録
   ↓
3. MinIO バケット構造
   storage-bucket/
   ├─ user1-uuid/file1-uuid-filename.pdf
   ├─ user1-uuid/file2-uuid-photo.jpg
   ├─ user2-uuid/...
   └─ ...

// ファイル削除
1. DELETE /api/v1/files/{fileId}
   - 所有権検証
   ↓
2. files.service.deleteFile()
   - if (file.storage_key) MinIO から削除
   - DB から削除
   - 子ファイルもカスケード削除
   - used_bytes を減分
   ↓
3. フォルダ削除時は再帰的に子ファイル削除

// ファイルバージョニング
- ファイル更新時に FileVersion レコード作成
- 過去バージョンへのロールバック可能
```

#### **ファイル共有機能**

```typescript
// 共有リンク作成
1. POST /api/v1/files/{fileId}/share
   - token: ランダム生成 (URL安全な形式)
   - expires_at: 有効期限設定可能
   - password_hash: オプション (パスワード保護)
   - max_downloads: オプション (ダウンロード数制限)
   ↓
2. 共有URL例:
   https://kawamonn.com/share/{token}
   ↓
3. GET /api/v1/share/{token}
   - パスワード確認 (パスワード設定時)
   - downloader_count チェック
   - ファイルをダウンロード

// 監査
- Share 作成/アクセスは全て AuditLog に記録
- metadata に token, client_ip 等を保存
```

---

### 2️⃣ **kawamonn-storage-frontend** (Vite + React)

モダンなシングルページアプリケーション UI

- **言語**: TypeScript
- **フレームワーク**: React
- **ビルドツール**: Vite (高速開発・本番ビルド)
- **UI ライブラリ**: Mantine (@mantine/core, @mantine/hooks)
- **アイコン**: Tabler Icons
- **HTTP Client**: axios

**主要ページ:**

```
/login
  ↓ JWT 取得
/dashboard
  ├─ ファイルリスト表示
  ├─ 見出しにストレージ使用量表示
  └─ ファイル操作: アップロード、削除、共有
/share/{token}
  └─ 公開共有リンク（パスワード保護対応）
```

---

## 🔐 セキュリティ機構

| セキュリティ項目 | 実装 |
|----------------|------|
| **認証** | ログイン時に email/password で JWT 発行 |
| **暗号化** | bcrypt (bcrypt_log_rounds=12) + argon2 |
| **パスワード** | 最小8文字、再度変更時に前パスワード確認 |
| **2要素認証** | TOTP (オプション) |
| **セッション管理** | NestJS: JWT ベースのセッション管理 |
| **ディレクトリトラバーサル対策** | `get_absolute_path()` で path validation |
| **クォータ管理** | ext4 project quota + DB `used_bytes` チェック |
| **監査ログ** | すべてのログイン、ファイル操作を記録 |
| **CORS** | NestJS で enableCors() |
| **API Validation** | class-validator で DTO 検証 |
| **Cloudflare** | DDoS 保護、WAF、Zero Trust Access |

---

## 🚀 デプロイ・運用

### **プロセス管理** （PM2）

Node.jsベースの NestJS アプリケーションは PM2 によって管理されています。

```bash
# pm2によるプロセス起動・管理
$ pm2 start ecosystem.config.js
$ pm2 status
$ pm2 logs kawamonn-api
```

### **Docker Compose** （kawamonn-storage/infrastructure/docker/）

バックエンド用のインフラ:

```yaml
services:
  - PostgreSQL (メタデータDB)
  - MinIO (ファイルストレージ)
  - Redis (キャッシュ)
  - SSH Provisioning Service
```

### **Cloudflare Integration**

- **DNS**: kawamonn.com ドメイン
- **Zero Trust Access**: @u-aizu.ac.jp ユーザーのみアクセス許可
- **Cloudflare Tunnel (cloudflared)**: Raspi5 をインターネットに露出させずに公開

---

## 📊 ユーザーライフサイクル

```
@u-aizu.ac.jp ユーザー:

登録
  ↓
作成
  ├─ status = PENDING → ACTIVE
  ├─ expiry_at = now + 4years
  └─ quota_bytes = 20GB
  ↓
日次バックグラウンドタスク (BullMQ)
  ├─ 6ヶ月前: リマインダメール
  ├─ 3ヶ月前: リマインダメール
  ├─ 1ヶ月前: リマインダメール
  ├─ 1週間前: 毎日リマインダメール
  └─ 3日前: 最終通告メール
  ↓
有効期限到達
  ├─ status = SUSPENDED
  ├─ ユーザーディレクトリ削除スクリプト実行 (管理者)
  ├─ DB レコード: status = DELETED
  └─ データ完全削除
```

---

## 🗂️ ディレクトリ構造解説

```
/home/pi/hdd/ssh/
├─ kawamonn-storage/           (NestJS + React モダンスタック)
│  ├── kawamonn-storage-backend/  (NestJS API)
│  │   ├── src/
│  │   │   ├── auth/           (認証・登録)
│  │   │   ├── files/          (ファイル管理)
│  │   │   ├── users/          (ユーザー用)
│  │   │   ├── admin/          (管理者)
│  │   │   ├── ssh/            (SSH/コンテナ管理)
│  │   │   ├── prisma/         (DB接続)
│  │   │   └── main.ts
│  │   │
│  │   ├── prisma/
│  │   │   └── schema.prisma   (DB スキーマ定義)
│  │   │
│  │   ├── package.json        (Node依存)
│  │   └── dist/               (ビルド出力)
│  │
│  ├── kawamonn-storage-frontend/  (React SPA)
│  │   ├── src/
│  │   ├── public/
│  │   ├── package.json
│  │   ├── vite.config.ts
│  │   └── dist/               (本番ビルド)
│  │
│  ├── infrastructure/         (インフラ)
│  │   └── docker/
│  │       └── docker-compose.yml  (PostgreSQL, MinIO, Redis)
│  │
│  ├── docs/
│  │   ├── er_diagram.mermaid      (DB ER図)
│  │   ├── openapi.yaml            (API 仕様)
│  │   └── schema.sql              (DDL)
│  │
│  └── ecosystem.config.js     (PM2プロセス管理)
│
└─ users/                      (ユーザーデータディレクトリ)
   ├── user1/                  (ファイル保存場所)
   ├── user2/
   └── ...
```

---

## 🔄 データフロー例

### シナリオ: ファイルアップロード（完全フロー）

```
ステップ1: フロントエンド (React)
  ┌─ ユーザーがファイル選択
  ├─ form-data として multipart/form-data で送信
  └─ POST /api/v1/files/upload

ステップ2: NestJS Backend
  ┌─ JWT トークン検証 (Passport JWT)
  ├─ ユーザーID取得 user.id
  ├─ files.service.uploadFile() 呼び出し
  │
  └─ files.service 内:
      ├─ user.quota_bytes と user.used_bytes チェック
      │  └─ 超過なら Exception
      │
      ├─ MinIO にアップロード
      │  └─ storageKey = "{userId}/{fileId}-{originalname}"
      │
      ├─ Prisma で File レコード作成
      │  └─ owner_id, name, size, storage_key, mime_type
      │
      ├─ User の used_bytes を increment
      │  └─ used_bytes += file.size
      │
      └─ AuditLog レコード作成
         └─ action: "UPLOAD", target_type: "file"

ステップ3: レスポンス
  └─ フロントエンドに { id, name, size, ... } を返却
     ユーザーの画面にファイルが表示
```

### シナリオ: ユーザー有効期限リマインダ

```
定期ジョブ (BullMQ cron)
  └─ checkReminders() タスク実行

checkReminders タスク:
  ├─ 全 ACTIVE ユーザーをスキャン (expiry_at != NULL)
  │
  ├─ ユーザーごとに残り日数計算
  │  └─ days_left = (user.expiry_at - now).days
  │
  ├─ 以下の条件でメール送信ジョブをキュー登録:
  │  ├─ days_left in [180, 150, 120, 90, 60]  → 標準通知
  │  ├─ days_left == 30                       → 最終通告
  │  └─ 1 <= days_left <= 7                   → 毎日催促
  │
  └─ BullMQ Worker が非同期で処理:
     ├─ Nodemailer で SMTP で送信
     ├─ Mailgun API (オプション)
     └─ 監査ログに記録
```

---

## 💡 重要な特徴とポイント

### ✅ **アカウント有効期限管理**

@u-aizu.ac.jp ユーザーは自動的に4年後に有効期限設定され、段階的にリマインダメール送信 → 最終的に削除

→ 学生の卒業に合わせたデータ削除を自動化

### ✅ **クォータシステム**

2重管理:
1. **ext4 project quota** (OS レベル): 物理的な制限
2. **DB used_bytes チェック** (アプリレベル): 論理的な制限

これにより、ディスク満杯を防止

### ✅ **監査ログの徹底**

- すべてのログイン記録
- ファイル操作（アップロード/削除）
- 管理者による操作実行者記録

コンプライアンス・セキュリティ対策

---

## 🚀 今後の拡張計画

### 新機能: SSH & VS Code Server サポート（実装予定）

Kawamonnは以下の機能を段階的に実装予定です：

```
Phase 1: SSH 接続サポート
   └─ VS Code Desktop の Remote SSH 対応
   └─ ターミナルからのアクティブな開発

Phase 2: VS Code Server 自動デプロイ
   └─ ブラウザベースのエディタ
   └─ 複数言語のコード編集・実行

Phase 3: 非アクティブ自動クリーンアップ
   └─ 30日以上非アクティブなら VS Code Server を自動削除
   └─ ディスク容量の効率的な運用

Phase 4: 有効期限管理との統合
   └─ 4年後の削除前に段階的な警告・バックアップ
   └─ @u-aizu.ac.jp のみ自動削除
```

**詳細実装プラン:** [SSH_VScodeServer_実装プラン.md](SSH_VScodeServer_実装プラン.md)

---

## 🎯 就職活動用アピールポイント

このプロジェクトをアピールする際に強調すべきこと:

### 1. **モダンなフルスタック開発能力**
- バックエンド: TypeScript/NestJS によるエンタープライズレベルのAPI
- フロントエンド: React/Vite によるシングルページアプリケーション
- インフラ: Docker, PM2, Cloudflare
- DB: PostgreSQL, Prisma ORM
- **拡張**: SSH インフラ、VS Code Server 統合（予定）

### 2. **堅牢なアーキテクチャ設計**
- バックエンド、フロントエンド、インフラ層の明確な分離
- MinIOを活用したスケーラブルなファイルストレージ
- 疎結合な設計

### 3. **高度なセキュリティ実装**
- JWT 認証
- パスワードハッシュ化 (bcrypt/argon2)
- 2要素認証 (TOTP)
- ディレクトリトラバーサル対策
- クォータ強制 (二重管理)
- 監査ログ

### 4. **運用性と可用性**
- PM2 でのプロセス監視と自動再起動
- Cloudflare Zero Trust で安全に公開
- BullMQ ジョブキューを使用した非同期タスク処理
- ログ管理

### 5. **ユーザーライフサイクル管理**
- 自動的なアカウント有効期限設定
- リマインダメール自動送信
- 段階的な削除プロセス

### 6. **スケーラビリティ**
- MinIO による分散ストレージ
- Redis キャッシング
- BullMQ ジョブキュー
- PostgreSQL

---

## 🚀 次のステップ

このプロジェクトをさらに強化するなら:

1. **Kubernetes 化** - スケーリングと冗長性向上
2. **CI/CD パイプライン** - GitHub Actions で自動デプロイ
3. **API ドキュメント** - Swagger/OpenAPI の充実
4. **エラーハンドリングの統一** - 全APIで一貫した仕様
5. **ロードバランシング** - nginx で複数インスタンスを負荷分散
6. **ログ集約** - ELK Stack (Elasticsearch, Logstash, Kibana)
7. **メトリクス監視** - Prometheus + Grafana

---

## 📚 参考資料

```
設定関連:
- kawamonn-storage/ecosystem.config.js
- .env                       (環境変数ファイル)
- kawamonn-storage/infrastructure/docker/docker-compose.yml

API 仕様:
- kawamonn-storage/docs/openapi.yaml
- kawamonn-storage/docs/er_diagram.mermaid
```

---

## 🎓 プレゼン構成案

**5分プレゼンの流れ:**

1. **導入** (30秒)
   - Kawamonn は Raspi 5 上で動作するオンラインストレージ
   - 会津大学の学生用に設計

2. **アーキテクチャ** (1分)
   - React + NestJS + PostgreSQL のモダンスタック
   - Diagram 提示

3. **主要機能** (1分30秒)
   - ユーザー登録・認証・ファイル管理
   - 20GB クォータ管理
   - @u-aizu.ac.jp 有効期限自動化
   - リマインダメール

4. **技術スタック** (1分)
   - バックエンド: NestJS, PostgreSQL, Prisma
   - フロントエンド: React, Vite, Mantine
   - インフラ: Docker, Cloudflare, MinIO, PM2

5. **セキュリティ・運用** (1分)
   - JWT + bcrypt 認証
   - 監査ログ
   - 非同期ジョブ(BullMQ)による自動管理
   - クォータシステム

---

このドキュメントを参考に、自分の言葉で説明できるようにしてください！
