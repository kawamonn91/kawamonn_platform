# Kawamonn - 実践的な運用ガイド

## 🛠️ よく使うコマンド集

### サービス管理

```bash
# 全サービスの状態確認
sudo systemctl status kawamonn-*.service

# 単一サービス再起動
sudo systemctl restart kawamonn-filemanager.service

# サービスの有効化（自動起動）
sudo systemctl enable kawamonn-register.service

# ライブログ見学
sudo journalctl -u kawamonn-register.service -f

# 過去のログを確認
sudo journalctl -u kawamonn-register.service -n 50  # 最後の50行

# 全サービスのログを時系列で見る
sudo journalctl -u kawamonn-*.service -f
```

### データベース操作

```bash
# PostgreSQL に接続
psql -U kawamonn -d kawamonn

# 全ユーザーを見る
SELECT id, username, email, status, quota_bytes, used_bytes FROM users;

# 特定ユーザーの詳細
SELECT * FROM users WHERE email = 'user@u-aizu.ac.jp';

# 有効期限が迫っているユーザー（30日以内）
SELECT username, email, expiry_at FROM users 
WHERE expiry_at IS NOT NULL 
  AND expiry_at < NOW() + INTERVAL '30 days'
ORDER BY expiry_at ASC;

# 監査ログの確認
SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 20;

# クォータを超過しているユーザー
SELECT username, used_bytes, quota_bytes FROM users 
WHERE used_bytes > quota_bytes;

# PostgreSQL を終了
\q
```

### Celery タスク管理

```bash
# Celery Worker が起動しているか確認
ps aux | grep celery

# Celery log を見る
tail -f /var/log/kawamonn/celery-worker.log

# Redis key を確認
redis-cli KEYS "*"

# 処理中のジョブを確認
redis-cli LLEN celery  # キューの長さ

# Celery から全てのタスクを削除（注意！）
redis-cli FLUSHDB

# Flower（Celery 監視ツール）を起動
celery -A worker.celery_app flower
# ブラウザで http://localhost:5555 にアクセス
```

### ユーザー管理

```bash
# 新規ユーザーディレクトリ作成
sudo /home/pi/hdd/ssh/kawamonn_platform/scripts/create_user_dir.sh \
    username \
    10001 \
    21474836480  # 20GB in bytes

# ユーザーを削除
sudo /home/pi/hdd/ssh/kawamonn_platform/scripts/delete_user.sh username

# ユーザーのクォータを変更
sudo /home/pi/hdd/ssh/kawamonn_platform/scripts/update_quota.sh \
    username \
    10001 \
    42949672960  # 40GB (新しい容量)

# ユーザーディレクトリのサイズを確認
du -sh /home/pi/hdd/ssh/users/username/

# クォータ使用状況を確認
repquota -P p | grep username
```

### ファイルシステム

```bash
# ディスク容量確認
df -h /home/pi/hdd/

# MinIO ストレージ確認
docker exec minio s3cmd ls

# ユーザーファイル統計
find /home/pi/hdd/ssh/users/ -type f | wc -l  # ファイル数
du -sh /home/pi/hdd/ssh/users/  # 合計容量

# 古いファイルを探す（3ヶ月以上前）
find /home/pi/hdd/ssh/users -type f -mtime +90

# ファイルの所有者と権限
ls -la /home/pi/hdd/ssh/users/username/
```

### Docker 操作

```bash
# Docker Compose サービス確認
docker-compose ps

# PostgreSQL ログを見る
docker-compose logs postgres -f

# MinIO ログを見る
docker-compose logs minio -f

# Redis ログを見る
docker-compose logs redis -f

# コンテナに進入
docker exec -it postgres psql -U kawamonn -d kawamonn

# コンテナを再起動
docker-compose restart postgres

# すべてのコンテナを停止
docker-compose down

# すべてのコンテナを起動
docker-compose up -d
```

---

## 🐛 トラブルシューティング

### 状況1: ユーザーがログインできない

#### 診断ステップ

```bash
# Step 1: ユーザーが DB に存在するか
psql kawamonn -c "SELECT * FROM users WHERE email='user@u-aizu.ac.jp';"

# 結果がない場合 → ユーザー未登録
# 結果がある場合 → Step 2 へ
```

```bash
# Step 2: パスワードハッシュは正しいか
# accounts/app.py で test
python3 -c "
from common.utils import check_password
stored_hash = '...'  # DB から取得したハッシュ
password = '...'     # ユーザー入力
result = check_password(password, stored_hash)
print('Password valid:', result)
"

# False が返ってくる → パスワード誤り
# True が返ってくる → Step 3 へ
```

```bash
# Step 3: JWT トークンは発行されるか (NestJS の場合)
curl -X POST http://localhost:3000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "account_name": "testuser",
    "password": "password"
  }' | jq

# 401 エラー → 認証失敗
# 200 + token 返却 → システムは OK。フロント側の問題？
```

#### 解決策

```bash
# パスワードをリセット
python3 << 'EOF'
from common.utils import hash_password
from common.models import User
from common.database import db
from common.config import Config

# Flask app context
from flask import Flask
app = Flask(__name__)
app.config.from_object(Config)
db.init_app(app)

with app.app_context():
    user = User.query.filter_by(email='user@u-aizu.ac.jp').first()
    if user:
        user.password_hash = hash_password('new_password')
        db.session.commit()
        print("Password reset successfully")
    else:
        print("User not found")
EOF
```

---

### 状況2: ファイルアップロードが失敗

#### 診断ステップ

```bash
# Step 1: ユーザーのクォータを確認
psql kawamonn -c "
SELECT username, used_bytes, quota_bytes, 
       quota_bytes - used_bytes AS remaining 
FROM users WHERE email='user@u-aizu.ac.jp';
"

# remaining が negative または 0 → クォータ超過
```

```bash
# Step 2: ext4 project quota を確認
repquota -P p | grep username

# Space limit が 0 → quota 未設定
# Space usage > limit → クォータ超過
```

```bash
# Step 3: MinIO が起動しているか
docker-compose logs minio | tail -20

# または
curl http://localhost:9000/minio/health/live
```

```bash
# Step 4: ディスク容量確認
df -h /home/pi/hdd/

# Available が 1GB未満 → ディスク満杯警告
```

#### 解決策

```bash
# Option A: ユーザーのクォータを増やす
sudo /home/pi/hdd/ssh/kawamonn_platform/scripts/update_quota.sh \
    username \
    10001 \
    42949672960  # 40GB に増加

# Option B: ユーザーの古いファイルを削除
# （管理者として） DB から削除
psql kawamonn -c "
DELETE FROM files 
WHERE owner_id = (
  SELECT id FROM users WHERE email='user@u-aizu.ac.jp'
) 
AND created_at < NOW() - INTERVAL '6 months';
"

# Option C: ディスク容量を増やす（物理的な対応）
# 外付け HDD追加などの検討
```

---

### 状況3: リマインダメールが送信されない

#### 診断ステップ

```bash
# Step 1: Celery Worker が起動しているか
sudo systemctl status kawamonn-worker.service

# 停止している → systemctl start
# 起動している → Step 2
```

```bash
# Step 2: Redis に接続できるか
redis-cli ping
# PONG が返ってくればOK

# PONG が返ってこない → redis-cli で接続確認
redis-cli -h localhost -p 6379 ping
```

```bash
# Step 3: Mailgun 設定を確認
echo "API Key: $MAILGUN_API_KEY"
echo "Domain: $MAILGUN_DOMAIN"

# 空白だった → env ファイル未設定
source ~/.env
# または .env ファイルを確認
cat /home/pi/hdd/ssh/kawamonn_platform/.env | grep MAILGUN
```

```bash
# Step 4: Celery Beat が起動しているか
sudo systemctl status kawamonn-beat.service

# log を見る
sudo journalctl -u kawamonn-beat.service -f
```

```bash
# Step 5: メール送信ログを確認
psql kawamonn -c "
SELECT * FROM mail_send_logs 
ORDER BY sent_at DESC LIMIT 10;
"
```

#### 解決策

```bash
# Celery Worker を再起動
sudo systemctl restart kawamonn-worker.service
sudo systemctl restart kawamonn-beat.service

# log が見たい場合
tail -100f /var/log/syslog | grep kawamonn

# Mailgun テスト
python3 << 'EOF'
from common.utils import send_email

success, response = send_email(
    'test@u-aizu.ac.jp',
    'Test Email',
    'This is a test email'
)

print("Success:", success)
print("Response:", response)
EOF
```

---

### 状況4: データベース接続エラー

#### エラーメッセージ例

```
could not connect to server: Connection refused
    Is the server running on host "localhost" (127.0.0.1) and accepting
    TCP connections on port 5432?
```

#### 診断ステップ

```bash
# Step 1: PostgreSQL が起動しているか
docker-compose ps  # postgres の状態確認

# STATUS が "Up" でない → 起動していない
```

```bash
# Step 2: PostgreSQL ログを確認
docker-compose logs postgres

# 典型的なエラー
# "FATAL: could not open relation mapping file" 
#   → データベースファイルが破損
```

```bash
# Step 3: ポート 5432 がリッスンしているか
sudo netstat -tlnp | grep 5432

# 何も返ってこない → PostgreSQL が待ち受けていない
```

#### 解決策

```bash
# PostgreSQL を再起動
docker-compose restart postgres

# 少し待つ（起動に時間がかかる）
sleep 10

# 接続テスト
psql -h localhost -U kawamonn -d kawamonn -c "SELECT 1;"
```

```bash
# もし起動しない場合：DB ボリュームを確認
docker-compose down

# データベースバックアップ
cp -r /home/pi/hdd/postgres_data /home/pi/hdd/postgres_data.backup

# データベースリセット（⚠️ 全データ削除）
rm -rf /home/pi/hdd/postgres_data

# Docker 再起動でマイグレーション実行
docker-compose up -d postgres

# NestJS マイグレーション (NestJS 環境の場合)
cd /home/pi/hdd/ssh/kawamonn-storage/kawamonn-storage-backend
npx prisma migrate deploy
```

---

### 状況5: Raspberry Pi CPU/メモリ不足

#### 症状

- Web UI が遅い
- アップロード完了に時間がかかる
- 時々 "503 Service Unavailable"

#### 診断

```bash
# リアルタイム監視
top

# または
htop

# メモリ使用状況
free -h

# CPU 温度確認
vcgencmd measure_temp

# ディスク I/O 状況
iostat 1 5

# プロセス別メモリ使用量
ps aux --sort=-%mem | head -20
```

#### 改善策

```bash
# 1. メモリ上限の設定
# Celery Worker のメモリ制限
# /etc/systemd/system/kawamonn-worker.service
[Service]
MemoryLimit=512M

# 2. キャッシュクリア
docker-compose exec redis redis-cli FLUSHDB

# 3. 古いログの削除
sudo journalctl --vacuum=100M

# 4. 不要なサービス停止
# 例：admin や home サービスを止めて負荷軽減
sudo systemctl stop kawamonn-admin.service
sudo systemctl stop kawamonn-home.service

# 5. スレッド数/ worker 数を減らす
# Nginx や gunicorn の設定で worker 数を削減
```

---

## 📋 定期メンテナンスチェックリスト

### 毎日

- [ ] リアルタイムログ確認（エラーがないか）
  ```bash
  sudo journalctl -u kawamonn-*.service -n 100
  ```

- [ ] Celery task queue にエラーが溜まっていないか
  ```bash
  redis-cli LLEN celery-failed
  ```

### 毎週

- [ ] ディスク容量確認
  ```bash
  df -h /home/pi/hdd/
  ```

- [ ] バックアップ実行
  ```bash
  tar -czf /backup/kawamonn-db-$(date +%Y%m%d).tar.gz \
      /home/pi/hdd/postgres_data
  ```

- [ ] ユーザー数 & ストレージ使用率
  ```bash
  psql kawamonn -c "
  SELECT 
    COUNT(*) as total_users,
    SUM(used_bytes) as total_stored,
    SUM(quota_bytes) as total_quota,
    ROUND(100.0 * SUM(used_bytes) / SUM(quota_bytes), 2) as utilization_pct
  FROM users;
  "
  ```

### 毎月

- [ ] 監査ログをアーカイブ・削除
  ```bash
  # 3ヶ月以上前のログを削除
  psql kawamonn -c "
  DELETE FROM audit_logs 
  WHERE timestamp < NOW() - INTERVAL '3 months';
  "
  ```

- [ ] セキュリティアップデート確認
  ```bash
  sudo apt update
  sudo apt list --upgradable
  ```

- [ ] SSL 証明書の有効期限確認
  ```bash
  # Cloudflare 使用中であれば自動更新なので OK
  ```

---

## 🚨 緊急対応ガイド

### 緊急! サービス完全停止

```bash
# 全サービス再起動
sudo systemctl restart kawamonn-*.service

# だめだったら、全サービス停止 → Docker 再起動 → 起動
sudo systemctl stop kawamonn-*.service
docker-compose restart
sleep 30
sudo systemctl start kawamonn-*.service
```

### 緊急! ディスク満杯

```bash
# 即座に停止（新規アップロード受け付けしない）
sudo systemctl stop kawamonn-filemanager.service

# 古いファイルを削除して容量確保
find /home/pi/hdd/ssh/users -type f -atime +180 -delete

# または DB から古いファイルメタデータを削除
psql kawamonn -c "
DELETE FROM files 
WHERE created_at < NOW() - INTERVAL '1 year';
"

# 容量が確保できたら再起動
sudo systemctl start kawamonn-filemanager.service
```

### 緊急! データベース破損疑い

```bash
# PostgreSQL バックアップを復元
# 最新のバックアップから復元
tar -xzf /backup/kawamonn-db-YYYYMMDD.tar.gz -C /

# PostgreSQL 再起動
docker-compose restart postgres

# 疑いの場合は FSCK で確認
sudo systemctl stop kawamonn-*.service
docker-compose down
sudo fsck -y /dev/sda1
```

---

## 📞 サポート記録テンプレート

発生した問題を記録しておくと、後で参考になります：

```
【日時】2026-03-01 14:30
【問題】ファイルアップロードが 504 Gateway Timeout
【原因】NestJS プロセスがメモリ不足でクラッシュ
【対応】
- メモリリークを確認（firebase admin sdk の初期化ミス）
- src/main.ts で修正後、再デプロイ
- 監視スクリプトを追加
【結果】解決 ✓
【学習】メモリリーク検出にはヒープダンプが有効
```

このような記録を付けておくと、後で問題が再発した時に対応が素早くなります。

