import * as nodemailer from 'nodemailer';
require('dotenv').config();

async function main() {
    const transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST || 'smtp.gmail.com',
        port: parseInt(process.env.SMTP_PORT || '465', 10),
        secure: true,
        auth: {
            user: process.env.SMTP_USER,
            pass: process.env.SMTP_PASS,
        },
    });

    try {
        await transporter.sendMail({
            from: `"UoA Online" <${process.env.SMTP_USER}>`,
            to: 'kawamonn91@gmail.com', // Using the sender email as receiver for testing
            subject: 'Test Password Reset Request',
            text: `Please click the link below to securely reset your password. This link will expire in 1 hour.`,
        });
        console.log('Sent successfully to kawamonn91@gmail.com');
    } catch (error) {
        console.error('Failed to send email:', error);
    }
}
main();
