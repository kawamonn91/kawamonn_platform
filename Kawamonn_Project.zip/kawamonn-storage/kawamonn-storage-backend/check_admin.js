const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
    const admins = await prisma.user.findMany({ where: { role: 'admin' } });
    if (admins.length > 0) {
        console.log("Admin Users Found:");
        admins.forEach(admin => {
            console.log(`- Email: ${admin.email}, Account Name: ${admin.account_name}`);
        });
    } else {
        console.log("No admin users found in the database. Please register an account first, then we can promote it.");
    }
}

main()
    .catch(e => {
        console.error(e);
        process.exit(1);
    })
    .finally(async () => {
        await prisma.$disconnect();
    });
