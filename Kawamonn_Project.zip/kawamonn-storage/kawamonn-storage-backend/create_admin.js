const { PrismaClient } = require('@prisma/client');
const argon2 = require('argon2');
const prisma = new PrismaClient();

async function main() {
    try {
        const hashedPassword = await argon2.hash('monnmo91');
        const user = await prisma.user.create({
            data: {
                account_name: 'admin_kawamonn',
                email: 'admin_kawamonn@u-aizu.ac.jp',
                password_hash: hashedPassword,
                display_name: 'Admin Kawamonn',
                role: 'admin'
            }
        });
        console.log('Created admin:', user.account_name);
    } catch (error) {
        console.error('Error creating admin:', error);
    } finally {
        await prisma.$disconnect();
    }
}

main();
