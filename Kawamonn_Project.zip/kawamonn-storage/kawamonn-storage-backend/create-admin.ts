import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  const hash = '$2b$12$CkJX0GDe1WmWqUR25NvjIOIGGygVvUw7ub3FnaNJ8BNjrkRQfhCxa'; // Admin@kawamonn2024!
  
  const user = await prisma.user.upsert({
    where: { account_name: 'kawamonn' },
    update: {
        password_hash: hash,
        role: 'admin'
    },
    create: {
      account_name: 'kawamonn',
      email: 'kawamonn91@gmail.com',
      password_hash: hash,
      role: 'admin',
      quota_bytes: 53687091200, // 50GB
    },
  });
  console.log('Admin user updated/created:');
  console.log(user);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
