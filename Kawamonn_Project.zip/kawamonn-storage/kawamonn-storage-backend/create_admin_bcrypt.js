const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcrypt');
const prisma = new PrismaClient();

async function main() {
    try {
        console.log("Hashing password...");
        const hashedPassword = await bcrypt.hash('monnmo91', 10);
        console.log("Inserting user into DB...");
        const user = await prisma.user.create({
            data: {
                account_name: 'admin_kawamonn',
                email: 'admin_kawamonn@u-aizu.ac.jp',
                password_hash: hashedPassword,
                display_name: 'Admin Kawamonn',
                role: 'admin'
            }
        });
        console.log('Created admin successfully:', user.account_name);
    } catch (error) {
        console.error('Error creating admin:', error);
    } finally {
        await prisma.$disconnect();
    }
}

main();
